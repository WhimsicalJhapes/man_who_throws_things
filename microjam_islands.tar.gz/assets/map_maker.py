import copy

import pygame

pygame.init()

screen_size = (1500, 800)
zoom = 10

default = 0

screen = pygame.display.set_mode(screen_size, pygame.RESIZABLE)

pygame.display.set_caption("tilemap editor")


def get_index(index, tilemap_):

    return tilemap_.subsurface((0, index * tile_size, tile_size, tile_size))


def draw_index(index, pos, scale_):

    tile_num = tiles[index]

    tile = pygame.transform.scale(tile_num, (scale_ * tile_size, scale_ * tile_size))
    
    screen.blit(tile, (pos))


def fill_map(w, h, col):
    global map_, map_back
    
    map_ = []
    map_back = []
    
    for row in range(h):
        
        map_.append([])
        map_back.append([])
        
        for i in range(w):
            
            map_[row].append(col)
            map_back[row].append(col)


def draw_map():

    for row in range(len(map_)):
        for collumn in range(len(map_[0])):
            draw_index(
                map_[row][collumn],
                (
                    collumn * scale * tile_size - camera_x,
                    row * scale * tile_size - camera_y,
                ),
                scale,
            )

    pygame.draw.rect(
        screen,
        (255, 255, 255),
        pygame.Rect(
            -camera_x,
            -camera_y,
            scale * len(map_[0]) * tile_size,
            scale * len(map_) * tile_size,
        ),
        3,
    )


def set_map(index, x, y):
    if 0 <= y < len(map_) and 0 <= x < len(map_[0]):
        map_[int(y)][int(x)] = index

def set_map_back(index, x, y):
    if 0 <= y < len(map_back) and 0 <= x < len(map_back[0]):
        map_back[int(y)][int(x)] = index


def selection():
    global select, can_up, can_down
    if (scroll == 1) and can_up:
        select = (select - 1) % tilemap_length
    elif (scroll == -1) and can_down:
        select = (select + 1) % tilemap_length
        
    size = ui_scale * tile_size
    for i in range(tilemap_length):
        draw_index(i, (screen_size[0] - size, i * size), ui_scale)
    pygame.draw.rect(
        screen, (0, 0, 0), ((screen_size[0] - size) - 10, select * size, 10, size)
    )



def draw_handling():
    mouse_pos = pygame.mouse.get_pos()
    size = scale * tile_size
    x = (mouse_pos[0] + camera_x) // size
    y = (mouse_pos[1] + camera_y) // size
    mouse = pygame.mouse.get_pressed()

    if mouse[0]:
        set_map(select, x, y)
    if mouse[2]:
        set_map(0, x, y)


def export_handling():
    if keys[pygame.K_e]:
        with open("exported.txt", "w") as f:
            f.write("[")
            for i in range(len(map_)):
                f.write(f"{str(map_[i])}")
                if not i == len(map_) - 1:
                    f.write(",\n")
            f.write("]")


def camera_handling():
    global past_mouse_pos, camera_x, camera_y

    current_mouse_pos = pygame.mouse.get_pos()
    change = (
        past_mouse_pos[0] - current_mouse_pos[0],
        past_mouse_pos[1] - current_mouse_pos[1],
    )
    if pygame.mouse.get_pressed()[1]:
        camera_x += change[0]
        camera_y += change[1]

    past_mouse_pos = current_mouse_pos


def input_handling():
    global \
        scale, \
        can_z, \
        can_x, \
        map_, \
        can_w, \
        can_a, \
        can_s, \
        can_d, \
        can_enter, \
        map_back
        
    if (keys[pygame.K_z]) and can_z:
        scale -= 0.5
        can_z = False
    elif (keys[pygame.K_x]) and can_x:
        scale += 0.5
        can_x = False

    if (keys[pygame.K_w]) and can_w:
        can_w = False

        map_.pop(-1)
        map_back.pop(-1)

        print(len(map_[0]), len(map_))
        

    if (keys[pygame.K_a]) and can_a:
        can_a = False

        for row in map_:
            row.pop(-1)
        for row in map_back:
            row.pop(-1)

        print(len(map_[0]), len(map_))
        

    if (keys[pygame.K_s]) and can_s:
        can_s = False

        map_.append([])
        for i in range(len(map_[1])):
            map_[-1].append(default)

        map_back.append([])
        for i in range(len(map_back[1])):
            map_back[-1].append(default)

        print(len(map_[0]), len(map_))
        

    if (keys[pygame.K_d]) and can_d:
        can_d = False

        for row in map_:
            row.append(default)
        for row in map_back:
            row.append(default)

        print(len(map_[0]), len(map_))
        

    if not keys[pygame.K_z]:
        can_z = True
    if not keys[pygame.K_x]:
        can_x = True

    if not keys[pygame.K_w]:
        can_w = True
    if not keys[pygame.K_a]:
        can_a = True
    if not keys[pygame.K_s]:
        can_s = True
    if not keys[pygame.K_d]:
        can_d = True
    if not keys[pygame.K_RETURN]:
        can_enter = True


tile_size = 8

tilemap_raw = pygame.image.load("assets/tileset.png")


tilemap_length = int(tilemap_raw.get_height() / tile_size)
scale = 8

tiles = []
for i in range(tilemap_length):
    tiles.append(get_index(i, tilemap_raw))

select = 0
scroll = 0

can_z = True
can_x = True

can_left = True
can_right = True
can_up = True
can_down = True

can_w = True
can_a = True
can_s = True
can_d = True
can_enter = True

camera_x = 0
camera_y = 0
past_mouse_pos = pygame.mouse.get_pos()

run = True
map_ = []
map_back = []

fill_map(8, 8, default)

while run:
    scroll = 0
    pygame.time.delay(10)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif event.type == pygame.MOUSEWHEEL:
            scroll = event.y

    keys = pygame.key.get_pressed()

    screen.fill((40, 40, 40))

    screen_size = (screen.get_width(), screen.get_height())

    ui_scale = screen_size[1] // (tilemap_length * tile_size)

    draw_map()

    draw_handling()
    camera_handling()
    export_handling()
    input_handling()
    selection()

    pygame.display.update()

pygame.quit()

"""
scroll / arrow - change tool
middle click - move cam
z / x - zoom
left / right click - draw / erase

wasd - change map size
arrow keys - move objects

enter - toggle mode

e - export
"""
