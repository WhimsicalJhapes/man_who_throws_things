import pygame as py
from modules.camera import CAMERA
from modules.gl import GL
from modules.player import PLAYER
from modules.ui import UI

import asyncio


py.init()
py.mixer.init()

# global
window_scale = 8
gl = GL(window_scale)

# screen stuff
screen = py.surface.Surface((gl.game_res[0] * gl.scale, gl.game_res[1] * gl.scale))
window = py.display.set_mode((gl.game_res[0] * window_scale, gl.game_res[1] * window_scale))

# objects
camera = CAMERA(screen, gl)
player = PLAYER(gl)
ui = UI(gl)

async def main():

    gl.play_music("menu")
    
    running = True
    while running:
        for event in py.event.get():
            if event.type == py.QUIT:
                running = False

        if gl.menu:
            # updates
            gl.update()
            camera.update(gl)
            

            # drawing
            screen.fill((0, 153, 219))
            gl.map.draw(screen, camera, gl)
            gl.menu_handling(screen, camera)
            
            if gl.space == 1:
                gl.menu = False
                gl.play_music("fight")
                camera.shake()
                gl.play_sfx("shuriken")
            
        else:
            if not gl.died:
                # updates
                gl.update()
                gl.game_update()
                camera.update(gl)
                player.update(gl)
                gl.update_entities(player, camera)
            
                # drawing
                screen.fill((0, 153, 219))
                gl.map.draw(screen, camera, gl)
                player.draw(screen, camera, gl)
                gl.draw_entities(screen, camera)
                ui.draw(screen, gl, player)
                gl.game_text_handling(screen, camera)

            else:
                gl.update()
                camera.update(gl)
                
                screen.fill((0, 153, 219))
                gl.map.draw(screen, camera, gl)
                gl.draw_entities(screen, camera)
                gl.end_screen(screen, camera)

                if gl.space == 30:
                    gl.reset(player)
                    gl.play_music("fight")
                    camera.shake()
                    gl.play_sfx("shuriken")
                

        # show
        transformed = py.transform.scale(screen, (window.get_width(), window.get_height()))
        window.blit(transformed, (0, 0))
        py.display.flip()
    
        gl.fps_handling()

        await asyncio.sleep(0.005)
        
    py.quit()

asyncio.run(main())
