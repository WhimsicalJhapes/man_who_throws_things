import pygame as py

from modules.item import Item
from modules.enemy import ENEMY
from modules.particle import Particle

class PROJECTILE:
    def __init__(self, gl, x, y, vector, speed, damage, sprite, collision, item_id):
        self.x = x
        self.y = y
        self.vector = gl.normalize(vector)
        self.speed = speed
        self.damage = damage
        self.collision = collision
        self.item_id = item_id

        self.xsp = self.vector[0] * self.speed
        self.ysp = self.vector[1] * self.speed

        if self.item_id == 0:
            gl.play_sfx("throw")
        elif self.item_id == 1:
            gl.play_sfx("throw")
        elif self.item_id == 2:
            gl.play_sfx("shoot")
        elif self.item_id == 3:
            gl.play_sfx("shuriken")
        elif self.item_id == 4:
            gl.play_sfx("throw")

        if self.item_id == 0:
            
            self.particle_timer = 0.1
            self.particle_length = 0.1

        elif self.item_id == 1:
            self.height = 0

            range_offset = self.vector
            
            range_offset[0] *= 35
            range_offset[1] *= 35
            
            self.target_pos = [self.x + range_offset[0], self.y + range_offset[1]]
            
            self.bomb_frame = 0
            self.bomb_frame_timer = 0
            self.bomb_frame_length = 0.2

        elif self.item_id == 3:
            self.bounces = 2

            self.particle_timer = 0.1
            self.particle_length = 0.1

        if self.item_id == 4 and self.vector[0] == 0:
            if self.vector[1] == 1:
                self.sprite = py.transform.rotate(sprite, 90)
                
            else:
                self.sprite = py.transform.rotate(sprite, -90)

        else:
            self.sprite = sprite

        if self.vector[0] > 0:
            self.sprite = py.transform.flip(self.sprite, True, False)


    def hit_enemy_check(self, gl):
        for enemy in gl.entities:
            if isinstance(enemy, ENEMY):
                
                selfrect = self.get_rect()
                enemyrect = enemy.get_rect()
                if selfrect.colliderect(enemyrect):
                    hit = enemy.hit(self.damage, gl)
                    
                    if hit:
                        if self.item_id == 2:
                            if self in gl.entities:
                                gl.entities.remove(self)

    def get_rect(self):
        x, y, w, h = self.collision
        x += self.x
        y += self.y
        return py.Rect(x, y, w, h)


    def get_rect_split(self):
        x, y, w, h = self.collision
        x += self.x
        y += self.y
        return x+1, y+1, w-1, h-1

    def update(self, gl, player, camera):
        

        if self.item_id == 0:
            self.x += self.xsp * gl.delta_time
            self.y += self.ysp * gl.delta_time
            
            x, y, w, h = self.get_rect_split()
            
            if gl.map.collide_rect(x, y, w, h):

                while gl.map.collide_rect(x, y, w, h):
                    self.x -= gl.sign(self.xsp)
                    self.y -= gl.sign(self.ysp)

                    x, y, w, h = self.get_rect_split()
                
                gl.entities.remove(self)
                gl.entities.append(Item(self.item_id, self.x, self.y-1, self.y, -120))
                gl.play_sfx("rock_hit")

                camera.shake()

            self.particle_timer -= gl.delta_time
            if self.particle_timer <= 0:
                self.particle_timer = self.particle_length
                gl.entities.insert(0, Particle(self.x + 4, self.y + 4, 0.3))

        elif self.item_id == 1:
            self.x += self.xsp * gl.delta_time
            self.y += self.ysp * gl.delta_time
            
            if self.x-2 < self.target_pos[0] < self.x+2 and self.y-2 < self.target_pos[1] < self.y+2:
                gl.entities.remove(self)

                target = self.target_pos
                target[0] += 3.5
                target[1] += 7
                gl.player_explosion(target[0], target[1], 20, 0.5, self.damage)

        elif self.item_id == 3:

            self.x += self.xsp * gl.delta_time

            bounced = False
            
            x, y, w, h = self.get_rect_split()
            
            if gl.map.collide_rect(x, y, w, h):
                
                while gl.map.collide_rect(x, y, w, h):
                    
                    self.x -= gl.sign(self.xsp)
                    self.y -= gl.sign(self.ysp)
                    
                    x, y, w, h = self.get_rect_split()

                self.xsp = -self.xsp
                bounced = True

            self.y += self.ysp * gl.delta_time
            
            x, y, w, h = self.get_rect_split()
            
            if gl.map.collide_rect(x, y, w, h):
                
                while gl.map.collide_rect(x, y, w, h):
                    
                    self.x -= gl.sign(self.xsp)
                    self.y -= gl.sign(self.ysp)
                    
                    x, y, w, h = self.get_rect_split()
                    
                self.ysp = -self.ysp
                bounced = True

            if bounced:
                self.bounces -= 1

            if self.bounces <= 0:
                gl.entities.remove(self)

            self.particle_timer -= gl.delta_time
            if self.particle_timer <= 0:
                self.particle_timer = self.particle_length
                gl.entities.insert(0, Particle(self.x + 4, self.y + 4, 0.3))
                    

        else:
            self.x += self.xsp * gl.delta_time
            self.y += self.ysp * gl.delta_time


        if not (-20 < self.x < gl.game_res[0]+20 and -20 < self.y < gl.game_res[1]+20):
            gl.entities.remove(self)

        self.hit_enemy_check(gl)
                

    def draw(self, screen, camera, gl):
        
        pos = camera.get_pos(self.x, self.y)

        if self.item_id == 1:
            pos[1] -= self.height

        screen.blit(self.sprite, pos)


        if self.item_id == 1:
            
            self.bomb_frame_timer += gl.delta_time
            if self.bomb_frame_timer >= self.bomb_frame_length:
                self.bomb_frame_timer = 0
                self.bomb_frame += 1
            if self.bomb_frame >= len(gl.bomb_target_frames):
                self.bomb_frame = 0
            
            bomb_target_sprite = gl.bomb_target_frames[self.bomb_frame]
            
            bomb_target_pos = camera.get_pos(self.target_pos[0], self.target_pos[1]+2)
            screen.blit(bomb_target_sprite, bomb_target_pos)
