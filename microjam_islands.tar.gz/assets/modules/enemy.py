
import pygame as py

from modules.enemy_projectile import EnemyProj
from modules.particle import Particle


import random as r

r.seed()

class ENEMY:
    def __init__(self, side, enemy_id, gl):
        
        if side == 0:
            self.x = -5
        else:
            self.x = gl.game_res[0] - 25
            
        self.y = gl.game_res[1] / 2 - 5

        self.xsp = 0
        self.ysp = 0
        
        self.enemy_id = enemy_id

        self.frame = 0
        self.frame_timer = 0
        self.frame_length = 0.25

        self.flip_x = False

        self.stun_timer = 0
        self.stun_length = 0.4

        self.timer = 0

        self.vulnerable = True

        if self.enemy_id == 0:
            self.speed = 10
            self.health = 3
            self.damage = 2
            
            self.frames = gl.fragment_spritesheet(gl.load_sprite("assets/goblin.png", 1), 8)
            self.width = 8
            self.height = 8

        if self.enemy_id == 1:
            self.speed = r.randint(13,16)
            self.overshoot_speed = 85
            
            self.health = 3.5
            self.damage = 2.5
            
            self.frames = gl.fragment_spritesheet(gl.load_sprite("assets/chomper.png", 1), 8)
            self.width = 8
            self.height = 8

            self.overshoot = 20
            self.overshoot_target = [0,0]

            self.state = "walking"
            self.walk_time = 2
            self.walk_range = 40

            self.timer = self.walk_time

            self.charge_time = 0.23
            self.charge_speed = 20

            self.particle_length = 0.12
            self.particle_timer = self.particle_length

        if self.enemy_id == 2:
            self.speed = r.randint(10,12)
            
            self.health = 4
            self.damage = 1.5
            
            self.frames = gl.fragment_spritesheet(gl.load_sprite("assets/dog.png", 1), 8)
            self.width = 9
            self.height = 8

            self.target = [r.randint(24, 160-32), r.randint(20, 128-28)]

            self.shoot_length = r.random()+2

            self.timer = r.random()+1

            self.bullet_speed = r.randint(45,50)

        if self.enemy_id == 3:
            self.speed = 120
            
            self.health = 6
            self.damage = 3.5
            
            self.frames = gl.fragment_spritesheet(gl.load_sprite("assets/blob.png", 1), 8)
            self.width = 10
            self.height = 8

            self.state = "idle"

            self.x = -50
            self.y = -20

            self.target = [-50, -20]

            self.idle_time = [2, 5]

        if self.enemy_id == 4:
            self.speed = 30
            
            self.health = 1
            self.damage = 2

            self.frames = gl.fragment_spritesheet(gl.load_sprite("assets/ghost.png", 1), 8)

            self.width = 8
            self.height = 8

            self.xsp = r.choice([self.speed, -self.speed])
            self.ysp = r.choice([self.speed, -self.speed])

            self.x = r.choice([1, gl.game_res[0] - 29])
            self.y = r.randint(1, gl.game_res[1]-10)

            self.particle_timer = 0.1
            self.particle_length = 0.2


    def offmap(self, gl):
        points = [[self.x, self.y], [self.x + self.width, self.y], [self.x, self.y + self.height], [self.x + self.width, self.y + self.height]]

        count = 0
        for point in points:
            if gl.map.point_off_map(*point):
                count += 1

        return count

    def update(self, gl, player, camera):
        if self.enemy_id == 0:
            vector = [player.x - self.x, player.y - self.y]
            normalized = gl.normalize(vector)
            
            self.xsp = normalized[0] * self.speed
            self.ysp = normalized[1] * self.speed

            self.attack_player(player,gl, camera)

        elif self.enemy_id == 4:

            self.attack_player(player, gl, camera)

            self.x += self.xsp * gl.delta_time
            
            if self.offmap(gl) != 0:
                
                while self.offmap(gl) != 0:
                    self.x -= gl.sign(self.xsp)

                self.xsp = -self.xsp

            self.y += self.ysp * gl.delta_time
            
            if self.offmap(gl) != 0:
                
                while self.offmap(gl) != 0:
                    self.y -= gl.sign(self.ysp)
                    
                self.ysp = -self.ysp

            self.particle_timer -= gl.delta_time
            if self.particle_timer <= 0:
                self.particle_timer = self.particle_length
                gl.entities.insert(0, Particle(self.x + 4, self.y + 4, 0.3))

            

        elif self.enemy_id == 3:
            
            if self.state == "idle":

                self.vulnerable = True
                
                distance = (self.target[1] - self.y)
                if distance < 10:
                    self.vulnerable = True
                    
                self.attack_player(player,gl, camera)

                self.xsp = 0
                self.ysp = 0

                self.x = self.target[0]
                self.y = self.target[1]
                
                self.timer -= gl.delta_time
                if self.timer <= 0:
                    self.state = "up"

            elif self.state == "up":
                self.vulnerable = False
                
                distance = (self.target[1] - self.y)
                if distance < 10:
                    self.vulnerable = True
                    
                self.ysp = -self.speed
                
                if self.y <= -20:
                    self.state = "down"
                    self.target = [player.x-3, player.y-4]
                    self.y = -100

            elif self.state == "down":
                self.vulnerable = False
                self.ysp = self.speed

                self.x = self.target[0]
                
                if self.y >= self.target[1]:
                    self.state = "idle"
                    self.timer = r.randint(*self.idle_time)
                    camera.shake(1, 0.3)
                    gl.play_sfx("explosion")
                    gl.enemy_explosion(self.x+self.width//2, self.y+self.height//2, 14, 0.4, self.damage)


        elif self.enemy_id == 1:

            self.attack_player(player,gl, camera)

            if self.state == "walking":
                
                vector = [player.x - self.x, player.y - self.y]
                
                self.timer -= gl.delta_time

                distance = gl.distance_squared((self.x, self.y), (player.x, player.y))
                
                if self.timer <= 0 and distance < self.walk_range**2:
                    self.state = "charging"
                    self.timer = self.charge_time

                    overshoot_offset = gl.normalize(vector)
                    overshoot_offset[0] *= self.overshoot
                    overshoot_offset[1] *= self.overshoot
                    self.overshoot_target = (player.x + overshoot_offset[0], player.y + overshoot_offset[1])
                    

                if distance < self.walk_range**2:
                    self.xsp = 0
                    self.ysp = 0
                    
                else:
                    
                    normalized = gl.normalize(vector)
                    
                    self.xsp = normalized[0] * self.speed
                    self.ysp = normalized[1] * self.speed

                if gl.sign(vector[0]) != 0:
                    if gl.sign(vector[0]) == -1:
                        self.flip_x = True
                    else:
                        self.flip_x = False

            if self.state == "charging":
                vector = [self.overshoot_target[0] - self.x, self.overshoot_target[1] - self.y]
                normalized = gl.normalize(vector)
                self.xsp = -normalized[0] * self.charge_speed
                self.ysp = -normalized[1] * self.charge_speed

                self.timer -= gl.delta_time

                if self.timer <= 0:
                    self.state = "overshoot"

                if gl.sign(normalized[0]) != 0:
                    if gl.sign(normalized[0]) == -1:
                        self.flip_x = True
                    else:
                        self.flip_x = False

            if self.state == "overshoot":

                vector = [self.overshoot_target[0] - self.x, self.overshoot_target[1] - self.y]
                normalized = gl.normalize(vector)
                self.xsp = normalized[0] * self.overshoot_speed
                self.ysp = normalized[1] * self.overshoot_speed

                if self.overshoot_target[0] - 2 < self.x < self.overshoot_target[0] + 2:
                    if self.overshoot_target[1] - 2 < self.y < self.overshoot_target[1] + 2:
                        
                        self.overshoot_target = [0, 0]
                        self.xsp = 0
                        self.ysp = 0
                        self.state = "walking"
                        self.timer = self.walk_time

                if not (-8 < self.x < gl.game_res[0] - 20 and -8 < self.y < gl.game_res[1]):

                    self.overshoot_target = [0, 0]
                    self.xsp = 0
                    self.ysp = 0
                    self.state = "walking"
                    self.timer = self.walk_time

                if gl.sign(self.xsp) != 0:
                    if gl.sign(self.xsp) == -1:
                        self.flip_x = True
                    else:
                        self.flip_x = False

                self.particle_timer -= gl.delta_time
                if self.particle_timer <= 0:
                    self.particle_timer = self.particle_length
                    gl.entities.insert(0, Particle(self.x + 4, self.y + 4, 0.5, (200, 200, 200)))
                    
                
        elif self.enemy_id == 2:
            
            self.attack_player(player,gl, camera)

            self.timer -= gl.delta_time
            if self.timer <= 0:
                self.timer = self.shoot_length
                self.shoot(player, gl)
                gl.sfx["dogshoot"].play()
                
            if self.target[0] - 2 < self.x < self.target[0] + 2:
                if self.target[1] - 2 < self.y < self.target[1] + 2:
                    self.target = [r.randint(24, 160-32), r.randint(20, 128-28)]
                    
            vector = [self.target[0] - self.x, self.target[1] - self.y]
            
            normalized = gl.normalize(vector)
            
            self.xsp = normalized[0] * self.speed
            self.ysp = normalized[1] * self.speed

        if self.enemy_id != 1:
            
            if gl.sign(self.xsp) != 0:
                if gl.sign(self.xsp) == -1:
                    self.flip_x = True
                else:
                    self.flip_x = False

        if self.enemy_id != 4:
            
            self.x += self.xsp * gl.delta_time
            self.y += self.ysp * gl.delta_time

        if self.stun_timer > 0:
            self.stun_timer -= gl.delta_time

        if self.health <= 0 and self.stun_timer <= 0.2:
            self.die(gl, player)


    def die(self, gl, player):
        gl.entities.remove(self)
        player.health += 0.5
        player.health = min(player.health, player.max_health)

        if self.enemy_id == 3:
            gl.play_sfx("rock_hit")


    def shoot(self, player, gl):
        gl.entities.insert(0, EnemyProj(self.x+self.width/2, self.y+self.height/2, (player.x - self.x, player.y - self.y), self.bullet_speed, self.damage, gl))


    def hit(self, damage, gl):
        if self.stun_timer > 0:
            return False

        if not self.vulnerable:
            return False

        gl.play_sfx("hit2")
        self.health -= damage
        self.stun_timer = self.stun_length

        return True

    def get_rect(self):
        return py.Rect(self.x, self.y, self.width, self.height)

    def attack_player(self, player,gl, camera):
        rect = self.get_rect()
        if rect.colliderect(player.rect):
            player.hit(self.damage, gl, camera)

    def draw(self, screen, camera, gl):
        if self.enemy_id == 0:
            gl.draw_shadow(screen, camera, self.x+1, self.y, self.width-1, self.height+1)
        elif self.enemy_id == 1:
            gl.draw_shadow(screen, camera, self.x+0.5, self.y+1, self.width, self.height+1)
        elif self.enemy_id == 2:
            gl.draw_shadow(screen, camera, self.x+0.5, self.y+0.5, self.width, self.height+1)
        elif self.enemy_id == 3:
            gl.draw_shadow(screen, camera, self.x+0.5, self.target[1]-0.75, self.width, self.height+1, height=3.5)
        elif self.enemy_id == 4:
            gl.draw_shadow(screen, camera, self.x+1, self.y, self.width-1, self.height+1)
        
        self.frame_timer += gl.delta_time
        if self.frame_timer >= self.frame_length:
            self.frame_timer = 0
            self.frame = (self.frame + 1) % len(self.frames)

        pos = camera.get_pos(self.x, self.y)

        sprite = self.frames[self.frame]

        if self.enemy_id == 3:
            if self.state != "idle":
                distance = (self.target[1] - self.y)
                sprite.set_alpha(max(255 - int(distance * 255 / 100), 0))
        
        if self.flip_x:
            sprite = py.transform.flip(sprite, True, False)
        if self.stun_timer > 0.1:
            sprite = gl.fill_sprite(sprite, (240, 240, 240))
            
        screen.blit(sprite, pos)
