import pygame as py

class EnemyProj:
    def __init__(self, x, y, vector, speed, damage, gl):
        self.x = x
        self.y = y
        self.vector = vector
        self.speed = speed
        self.damage = damage

        normalized = gl.normalize(vector)

        self.xsp = normalized[0] * self.speed
        self.ysp = normalized[1] * self.speed

        self.sprite = gl.load_sprite("assets/bullet.png")

    def get_rect(self):
        return py.Rect(self.x, self.y, self.sprite.get_width()-1, self.sprite.get_height()-1)

    def update(self, gl, player, camera):
        self.x += self.xsp * gl.delta_time
        self.y += self.ysp * gl.delta_time

        selfrect = self.get_rect()
        if selfrect.colliderect(player.get_rect()):
            player.hit(self.damage, gl, camera)

            if self in gl.entities:
                gl.entities.remove(self)
        
        
    def draw(self, screen, camera, gl):
        pos = camera.get_pos(self.x, self.y)
        screen.blit(self.sprite, pos)
