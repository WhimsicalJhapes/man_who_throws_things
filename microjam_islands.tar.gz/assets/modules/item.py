from pygame import Rect


class Item:
    def __init__(self, item_id, x, start_y, end_y, ysp=25):
        self.x = x
        self.y = start_y
        self.end_y = end_y # target y

        self.ysp = ysp

        self.falling = True
        self.gravity = not ysp == 25
        
        self.item_id = item_id

        self.gravity_speed = 20

    def update(self, gl, player, camera):
        if self.falling:
            if self.gravity:
                self.ysp += self.gravity_speed

            self.y += self.ysp * gl.delta_time
  
            if self.y >= self.end_y:
                self.y = self.end_y
                self.falling = False

        rect = Rect(self.x, self.y, 8, 8)
        
        if rect.colliderect(player.rect):
            if len(player.head_items_list) < player.max_head_item_count:
                gl.entities.remove(self)
                gl.play_sfx("pickup")
            
                player.add_head_item(self.item_id)

        if not (-20 < self.x < gl.game_res[0]+20 and -20 < self.y < gl.game_res[1]+20):
            gl.entities.remove(self)

    def draw(self, screen, camera, gl):

        if self.item_id == 0:
            gl.draw_shadow(screen, camera, self.x+2, self.end_y+1, 5, 8)
        
        pos = camera.get_pos(self.x, self.y)
        screen.blit(gl.head_item_frames[self.item_id], pos)
