
import pygame as py

class Particle:
    def __init__(self, x, y, lifetime, c=(255,255,255), size=1):
        self.x = x
        self.y = y
        self.timer = lifetime
        self.c = c
        self.size = size
        
    def update(self, gl, player, camera):
        self.timer -= gl.delta_time
        
        if self.timer <= 0:
            gl.entities.remove(self)

    def draw(self, screen, camera, gl):
        pos = camera.get_pos(self.x, self.y)
        rect = py.Rect(pos[0], pos[1], self.size*gl.scale, self.size*gl.scale)
        py.draw.rect(screen, self.c, rect)