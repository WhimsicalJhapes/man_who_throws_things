import pygame as py
import math

from modules.item import Item
from modules.map import MAP
from modules.enemy import ENEMY
from modules.explosion import Explosion


from random import randint, choice

class GL:
    def __init__(self, window_scale): 

        self.FPS = 60
        self.delta_time = 0.0
        self.real_delta_time = 0.0
        self.clock = py.time.Clock()

        self.scale = 2 # default 4
        self.window_scale = window_scale

        self.game_res = (160+20, 128) # (20,16) tiles

        self.font = py.font.Font('assets/font.ttf', 16*self.scale)

        self.reset()

        self.menu = True

        self.paused = False

        self.sfx = {
            "explosion": py.mixer.Sound("assets/sfx/explosion.ogg"),
            "hit": py.mixer.Sound("assets/sfx/hit.ogg"),
            "rock_hit": py.mixer.Sound("assets/sfx/rock_hit.ogg"),
            "shuriken": py.mixer.Sound("assets/sfx/shuriken.ogg"),
            "throw": py.mixer.Sound("assets/sfx/throw.ogg"),
            "shoot": py.mixer.Sound("assets/sfx/shoot.ogg"),
            "hit2": py.mixer.Sound("assets/sfx/hit2.ogg"),
            "pickup": py.mixer.Sound("assets/sfx/pickup.ogg"),
            "talk": py.mixer.Sound("assets/sfx/talk.ogg"),
            "dogshoot": py.mixer.Sound("assets/sfx/dogshoot.ogg"),
        }

        self.sfx["explosion"].set_volume(0.1)
        self.sfx["rock_hit"].set_volume(0.5)
        self.sfx["shuriken"].set_volume(0.7)
        self.sfx["throw"].set_volume(0.1)
        self.sfx["shoot"].set_volume(0.3)
        self.sfx["hit2"].set_volume(0.5)
        self.sfx["pickup"].set_volume(0.5)
        self.sfx["talk"].set_volume(0.5)
        self.sfx["dogshoot"].set_volume(0.2)

        self.text_timer = 0.0
        self.text = ""

    def reset(self, player=None):
        self.menu = False

        self.died = False

        self.won = False
        
        self.game_speed_mul = 1
        self.game_target_mul = 1
        
        self.item_fall_length = 10
        self.item_fall_timer = 3

        self.falling_items = []

        self.k1 = 0
        self.k2 = 0

        self.w = 0
        self.s = 0
        self.a = 0
        self.d = 0

        self.e = 0
        self.q = 0

        self.r_click = 0
        self.l_click = 0

        self.enter = 0
        
        self.ctrl = 0
        self.space = 0

        self.dev = False

        self.map = MAP(self)

        self.entities = []

        self.head_item_frames = self.fragment_spritesheet(self.load_sprite("assets/headitems.png", 1), 8)
        self.bomb_target_frames = self.fragment_spritesheet(self.load_sprite("assets/target.png", 1), 7)

        self.shadow = self.load_sprite("assets/shadow.png", 1)

        self.wave = 1
        self.wave_timer = 0

        self.waves = [
            [
                [0, 1, 2], # enemy, side, time
            ],
            [
                [0, 1, 2],
                [0, 0, 4],
                [0, 1, 6],
                [0, 0, 8],
            ],
            [
                [1, 1, 4],
                [1, 0, 10],
            ],
            [
                [0, 1, 10],
                [0, 1, 10.5],
                [0, 1, 11],
                [0, 1, 11.5],
                [0, 1, 12],
                [0, 0, 15],
                [0, 0, 15.5],
                [0, 0, 16],
                [0, 0, 16.5],
                [0, 0, 17],
            ],
            [
                [2, 1, 4],
                [2, 0, 4],
            ],
            [
                [2, 1, 4],
                [0, 0, 6],
                [0, 0, 7],
                [1, 1, 8],
            ],
            [
                [2, 0, 4],
                [2, 1, 6],
                [2, 0, 12],
                [2, 1, 14],
                [2, 1, 20],
                [2, 0, 22],
            ],
            [
                [1, 1, 4],
                [1, 0, 4],
                [2, 0, 12],
                [2, 1, 12],
                [0, 1, 16],
                [0, 0, 16],
            ],
            [
                [1, 0, 4],
                [1, 1, 6],
                [1, 0, 12],
                [1, 1, 14],
                [1, 1, 20],
                [1, 0, 22],
            ],
        ]

        count = 7
        time = 4
        
        while len(self.waves) < 25:

            wave = []

            for i in range(count):
                side = randint(0, 1)
                if len(self.waves) < 10:
                    enemy = choice([0, 1, 1, 2, 2])
                elif len(self.waves) < 15:
                    enemy = choice([0, 1, 1, 2, 3])
                else:
                    enemy = choice([0, 1, 4, 2, 3])
                
                wave.append([enemy, side, time])
                
                if len(self.waves) > 20:
                    time += randint(1, 2)
                else:
                    time += randint(2, 3)

            self.waves.append(wave)

            if len(self.waves) % 2 == 0:
                count += 1

            time = 4

        self.waves[9] = [
            [3, 1, 2],
            [3, 0, 10],
        ]

        self.waves[10] = [
            [3, 1, 4],
            [3, 0, 6],
            [1, 1, 8],
            [2, 0, 8.5],
        ]

        self.waves[24] = [
            [3, 1, 4],
            [3, 1, 5],
            [3, 1, 6],
            [3, 1, 7],

            [1, 1, 7],
            [4, 1, 8],
            [1, 1, 9],
            [4, 1, 7],
            [1, 1, 8],
            [4, 1, 9],

            [1, 0, 20],
            [1, 1, 21],
            [0, 0, 22],
            [1, 0, 23],
            [0, 1, 24],
            [1, 0, 25],

            [2, 1, 23],
            [2, 0, 24],
            [2, 1, 25],
            [2, 1, 26],
            
            [3, 1, 30],
            [3, 1, 31],
            [3, 1, 32],
        ]

        if player != None:
            player.reset()

    def die(self, camera, won=False):
        self.died = True
        self.play_sfx("explosion")

        camera.shake(1, 1)

        self.play_music("died")

        self.won = won

    def end_screen(self, screen, camera):
        
        shadow = py.transform.scale(self.shadow, (140 * self.scale, 112 * self.scale))
        shadow.set_alpha(215)

        pos = camera.get_pos(8, 10)
        screen.blit(shadow, pos)

        if self.won:
            self.draw_text(screen, "You Won!", *camera.get_pos(15, 18), (255, 255, 255), shadow=2)
        else:
            self.draw_text(screen, "Thanks For Playing!", *camera.get_pos(15, 18), (255, 255, 255), shadow=2)
            
        self.draw_text(screen, f"Wave - {self.wave}", *camera.get_pos(15, 35), (255, 255, 255), shadow=2)
        self.draw_text(screen, "Hold [SPACE] to restart", *camera.get_pos(15, 17+35), (255, 255, 255), shadow=2)
        self.draw_text(screen, "Made by Whimsical Jhapes", *camera.get_pos(20, 112), (255, 255, 255), shadow=1, scale=0.5)

    def paused_screen(self, screen, camera):
        shadow = py.transform.scale(self.shadow, (51*self.scale, 16*self.scale))
        shadow.set_alpha(215)

        location = (54,55)
        pos = camera.get_pos(*location)
        screen.blit(shadow, pos)
        
        self.draw_text(screen, "Paused", *camera.get_pos(location[0]+8, location[1]+3), (255, 255, 255), shadow=2)
        

    def play_sfx(self, sound):
        self.sfx[sound].play()

    def play_music(self, music):
        py.mixer.music.load(f"assets/music/{music}.ogg")
        py.mixer.music.play(-1)
        py.mixer.music.set_volume(0.5)

        if music == "died":
            py.mixer.music.set_volume(1)

    def fill_sprite(self, sprite, color):
        mask = py.mask.from_surface(sprite)
        return mask.to_surface(
            setcolor=color,
            unsetcolor=(0, 0, 0, 0)
        ).convert_alpha()

    def load_sprite(self, path, scale=-1):
        if scale == -1:
            scale = self.scale
            
        sprite = py.image.load(path)
        sprite = py.transform.scale(sprite, (sprite.get_width() * scale, sprite.get_height() * scale))
        return sprite


    def enemy_explosion(self, x, y, radius, duration, damage):
        self.entities.insert(0, Explosion(x, y, radius, duration, damage, self, True))

    def player_explosion(self, x, y, radius, duration, damage):
        self.entities.insert(0, Explosion(x, y, radius, duration, damage, self, False))


    def draw_shadow(self, screen, camera, x, y, w, h, height=2, opacity=50):
        
        shadow_pos = x-1, y+h-2

        shadow = py.transform.scale(self.shadow, ((w+1)*self.scale, height*self.scale))
        shadow.set_alpha(opacity)

        pos = camera.get_pos(*shadow_pos)
        screen.blit(shadow, pos)

    def menu_handling(self, screen, camera):
        if self.menu:
            
            self.draw_text(screen, "press [SPACE] to start", *camera.get_pos(22, 90), (255, 255, 255), shadow=1)
            self.draw_text(screen, "Man Who Throws Things", *camera.get_pos(23, 20), (255, 255, 255), shadow=2)

    def draw_text(self, screen, text, x, y, c, scale = 1, shadow=0):
        text_surface = self.font.render(text, False, c)
        text_surface = py.transform.scale(text_surface, (text_surface.get_width() * scale, text_surface.get_height() * scale))
        if shadow != 0:
            shadow_surface = self.font.render(text, False, (0, 0, 0))
            shadow_surface = py.transform.scale(shadow_surface, (shadow_surface.get_width() * scale, shadow_surface.get_height() * scale))
            shadow_surface.set_alpha(100)
            screen.blit(shadow_surface, (x, y + self.scale*shadow))
        screen.blit(text_surface, (x, y))

    def show_text(self, text, time, noise=True):
        if self.text == text:
            return
        
        if noise:
            self.play_sfx("talk")
            
        self.text_timer = time
        self.text = text

        if text == "You get a rock":
            self.entities.append(Item(0, 100, 40, 60, -120))

    def range(self, num, time):
        return num < time < num + 1

    def game_text_handling(self, screen, camera):
        
        
        if self.wave == 1:

            if self.range(2, self.wave_timer):
                self.show_text("FIGHT!", 2)
            if self.range(11, self.wave_timer):
                self.show_text("Umm?", 2)
            if self.range(12, self.wave_timer):
                self.show_text("Why are you not fighting?", 3)
            if self.range(16, self.wave_timer):
                self.show_text("Do you need a weapon?", 3)
            if self.range(20, self.wave_timer):
                self.show_text("I'll see what i can find", 3)
            if self.range(26, self.wave_timer):
                self.show_text("Here", 1)
            if self.range(27, self.wave_timer):
                self.show_text("You get a rock", 3)
            if self.range(30, self.wave_timer):
                self.show_text("Use [SPACE] to throw it", 10)

        if self.wave == 4:

            self.falling_items = [1]

            if self.range(2, self.wave_timer):
                self.show_text("try catching these bombs!", 3)

            if self.range(5.5, self.wave_timer):
                self.show_text("items stack on the right", 4)

        if self.wave in [5, 6]:
            self.falling_items = [1]

        if self.wave == 7:
            self.falling_items = [1, 2]

        if self.wave == 8:
            self.falling_items = [1, 2, 3]

        if self.wave >= 9:
            self.falling_items = [1, 2, 3, 4]

            self.item_fall_length = 6

        enemies = 0
        for enemy in self.entities:
            if isinstance(enemy, ENEMY):
                enemies += 1

        if enemies == 0 and self.wave_timer > self.waves[self.wave - 1][-1][2]:
            if self.wave == len(self.waves):
                self.die(camera, True)
                
            else:
                self.wave += 1
                self.wave_timer = 0
                if self.wave != 25:
                    self.show_text(f"Wave {self.wave}", 2)
                else:
                    self.show_text("FINAL WAVE", 4)

        # show text
        text_pos = camera.get_pos(7, 12)
        
        if self.text_timer > 0:
            self.text_timer -= self.delta_time
            self.draw_text(screen, self.text, text_pos[0], text_pos[1], (255, 255, 255), shadow=1)
        else:
            self.text = ""

    def game_update(self):
        
        # item fall timer
        if len(self.falling_items) > 0:
            
            if self.item_fall_timer > 0:
                self.item_fall_timer -= self.delta_time
            else:
                self.item_fall_timer = self.item_fall_length
                self.entities.append(Item(choice(self.falling_items), randint(40, 120), -16, 160))

        # wave handling
        self.wave_timer += self.delta_time
        
        for enemy in self.waves[self.wave - 1]:
            if self.wave_timer >= enemy[2] and len(enemy) == 3:
                self.spawn_enemy(enemy[0], enemy[1])
                enemy.append(True)   
             
        

    def pause_handling(self, camera):
        # pause handling

        if self.enter == 1:
            self.paused = not self.paused
            camera.shake()
            self.play_sfx("pickup")
        
    def update(self):
        # print(self.w, self.a, self.s, self.d)

        self.game_speed_mul = self.lerp(self.game_speed_mul, self.game_target_mul, 0.05)

        key = py.key.get_pressed()
        if key[py.K_w] or key[py.K_UP]:
            self.w += 1
        else:
            self.w = 0

        if key[py.K_a] or key[py.K_LEFT]:
            self.a += 1
        else:
            self.a = 0

        if key[py.K_s] or key[py.K_DOWN]:
            self.s += 1
        else:
            self.s = 0

        if key[py.K_d] or key[py.K_RIGHT]:
            self.d += 1
        else:
            self.d = 0

        if key[py.K_1]:
            self.k1 += 1
        else:
            self.k1 = 0

        if key[py.K_2]:
            self.k2 += 1
        else:
            self.k2 = 0


        if key[py.K_SPACE] or key[py.K_z]:
            self.space += 1
        else:
            self.space = 0

        if key[py.K_LCTRL]:
            self.ctrl += 1
        else:
            self.ctrl = 0

        if key[py.K_e]:
            self.e += 1
        else:
            self.e = 0

        if key[py.K_q]:
            self.q += 1
        else:
            self.q = 0

        if key[py.K_RETURN] or key[py.K_p]:
            self.enter += 1
        else:
            self.enter = 0

        mouse = py.mouse.get_pressed()
        if mouse[2]:
            self.r_click += 1
        else:
            self.r_click = 0

        if mouse[0]:
            self.l_click += 1
        else:
            self.l_click = 0

    def spawn_enemy(self, enemy_type, side):
        
        
        self.entities.append(ENEMY(side, enemy_type, self))

    
    def fps_handling(self):
        self.delta_time = self.clock.tick(self.FPS) / 1000.0
        self.real_delta_time = self.delta_time
        self.delta_time *= self.game_speed_mul

    def update_entities(self, player, camera):
        for entity in self.entities:
            entity.update(self, player, camera)

    def draw_entities(self, screen, camera):
        for entity in self.entities:
            entity.draw(screen, camera, self)

    def fragment_spritesheet(self, sprite_sheet, sprite_size):
        tiles = []
        
        width = sprite_sheet.get_width() 
        height = sprite_sheet.get_height() // sprite_size
        
        for y in range(height):

            tile = sprite_sheet.subsurface(py.Rect(0, y * sprite_size, width, sprite_size))
            tile = py.transform.scale(tile, (tile.get_width() * self.scale, tile.get_height() * self.scale))
            tiles.append(tile)
                
        return tiles

    def lerp(self, num1, num2, t):
        return num1 + (num2 - num1) * t

    def lerp_angle(self, angle1, angle2, t):
        diff = (angle2 - angle1) % 360
        if diff > 180:
            diff -= 360
        return angle1 + diff * t

    def normalize(self, vector):
        magnitude = math.sqrt(vector[0]**2 + vector[1]**2)
        
        if magnitude == 0:
            raise ValueError("Cannot normalize a zero vector.")
        
        new_x = vector[0]/magnitude
        new_y = vector[1]/magnitude
        
        return [new_x, new_y]

    def sign(self, num):
        if num < 0:
            return -1
        elif num > 0:
            return 1
        else:
            return 0

    def polar(self, angle, magnitude):
        angle = - angle
        return [math.cos(math.radians(angle)) * magnitude, math.sin(math.radians(angle)) * magnitude]

    def distance_squared(self, pos1, pos2):
        xdis = pos2[0] - pos1[0]
        ydis = pos2[1] - pos1[1]
        return xdis**2 + ydis**2    