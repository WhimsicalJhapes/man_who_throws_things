import pygame as py

class MAP:
    def __init__(self, gl):
        self.map = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
            [0, 0, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 0, 0],
            [0, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3],
            [4, 4, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 4, 4, 4],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 5, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 5, 0, 0, 0],
            [0, 0, 0, 0, 0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        ]

        self.width = len(self.map[0])
        self.height = len(self.map)

        self.tile_size = 8
        self.scale = gl.scale

        self.tileset = gl.load_sprite("assets/tileset.png", 1)
        
        self.tileset_collisions = [
            1, # water
            0, # grass
            0, # grass
            1, # bridge
            1, # cliff
            1, # bridge shadow
        ]

        self.tiles = gl.fragment_spritesheet(self.tileset, self.tile_size) 

    def draw(self, screen, camera, gl):


        collisions = []
    
        for y in range(len(self.map)):
            for x in range(len(self.map[y])):
                
                tile = self.get_tile(x, y)

                if tile == -1:
                    continue
                
                pos = camera.get_pos(x*self.tile_size, y*self.tile_size)
                self.show_tile(pos[0], pos[1], tile, screen)

                if gl.dev:
                    rect = self.get_tile_rect(x*self.tile_size, y*self.tile_size)
                    if rect != None:
                        collisions.append(rect)


        for rect in collisions:
            pos = camera.get_pos(rect.x, rect.y)
            rect.x, rect.y = pos
            
            rect.width *= camera.scale
            rect.height *= camera.scale
            py.draw.rect(screen, (255, 0, 0), rect, 1)

    def show_tile(self, x, y, tile, screen):
        screen.blit(self.tiles[tile], (x, y))

    def collide_point(self, x, y):
        if x < 0 or x >= self.width * self.tile_size or y < 0 or y >= self.height * self.tile_size:
            return True
        else:
            tile = self.get_tile(int(x/self.tile_size), int(y/self.tile_size))
            
            if tile == -1:
                return False
                
            collision_data = self.tileset_collisions[tile]
            
            if type(collision_data) == int:
                if collision_data == 0:
                    return False
                else:
                    return True
            else:
                tx, ty, w, h, = collision_data

                lx = x % self.tile_size
                ly = y % self.tile_size

                collidex = tx < lx <= tx + w
                collidey = ty < ly <= ty + h

                return collidex and collidey

    def point_off_map(self, x, y):
        return x < 0 or x >= self.width * self.tile_size or y < 0 or y >= self.height * self.tile_size

    def collide_rect(self, x, y, w, h):

        collided = False
        
        rect = py.Rect(x, y, w, h)

        left = int(x // self.tile_size)
        right = int((x + w - 1) // self.tile_size)
        
        top = int(y // self.tile_size)
        bottom = int((y + h - 1) // self.tile_size)
        
        tiles = []
        
        for ty in range(top, bottom + 1):
            for tx in range(left, right + 1):
                collision_rect = self.get_tile_rect(tx * self.tile_size, ty * self.tile_size)
                if not collision_rect in tiles:
                    tiles.append(collision_rect)

                off_map = self.point_off_map(tx * self.tile_size, ty * self.tile_size)

                if off_map:
                    collided = True
                    continue


        for tile in tiles:
            
            if tile == None:
                continue
                
            if tile.colliderect(rect):
                collided = True

        return collided

    def get_tile_rect(self, x, y):

        tile = self.get_tile(x//8, y//8)
        
        if tile == -1:
            return None
            
        collision_data = self.tileset_collisions[tile]
            
        if type(collision_data) == int:
            if collision_data == 0:
                return None

            else:
                return py.Rect(x, y, self.tile_size, self.tile_size)
            
        tx, ty, w, h = collision_data
        return py.Rect(x + tx, y + ty, w, h)

    def get_tile(self, x, y):

        if x < 0 or x >= self.width or y < 0 or y >= self.height:
            return -1
            
        tile = self.map[int(y)][int(x)]
       
        return tile

    

    