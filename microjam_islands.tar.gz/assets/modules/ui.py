import pygame as py

class UI:
    def __init__(self, gl):
        self.col = (20, 20, 20)

        self.ui_sprites = gl.fragment_spritesheet(gl.load_sprite("assets/headitems.png", 2), 16)

    def draw(self, screen, gl, player):

        rect = py.Rect((gl.game_res[0] - 19)*gl.scale, 3*gl.scale, 18*gl.scale, (gl.game_res[1] - 6)*gl.scale)
        py.draw.rect(screen, (40, 40, 40), rect)
        
        rect = py.Rect((gl.game_res[0] - 18)*gl.scale, 4*gl.scale, 16*gl.scale, (gl.game_res[1] - 8)*gl.scale)
        py.draw.rect(screen, self.col, rect)

        # head list ui
        for i in range(len(player.head_items_list)):
            num = player.head_items_list[i]
            sprite = self.ui_sprites[num]
            pos = [(gl.game_res[0]-18) * gl.scale, i * 20 * gl.scale + 3 * gl.scale]
            screen.blit(sprite, pos)
    
        # health ui
        back_rect = py.Rect(4*gl.scale, 4*gl.scale, 32 * gl.scale, 7 * gl.scale)
        py.draw.rect(screen, (40, 40, 40), back_rect)
        
        back_rect = py.Rect(5*gl.scale, 5*gl.scale, 30 * gl.scale, 5 * gl.scale)
        py.draw.rect(screen, (0, 0, 0), back_rect)
    
        front_rect = py.Rect(5*gl.scale, 5*gl.scale, 30 * gl.scale * (player.health / player.max_health), 5 * gl.scale)
        py.draw.rect(screen, (228, 60, 70), front_rect)