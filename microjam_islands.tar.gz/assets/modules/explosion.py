import pygame as py

from modules.enemy import ENEMY

class Explosion:
    def __init__(self, x, y, radius, duration, damage, gl, enemy=False):
        self.x = x
        self.y = y
        self.radius = 0
        self.max_radius = radius
        self.damage = damage

        self.enemy = enemy
        
        self.rps = radius / duration # radius per second

        gl.play_sfx("explosion")

        self.hit_list = []

    def hit_enemy_check(self, gl, camera, player):
        if not self.enemy:
            for enemy in gl.entities:
            
                if isinstance(enemy, ENEMY):
    
                    if enemy in self.hit_list:
                        continue
    
                    enemy_center = enemy.get_rect().center
                    distance = gl.distance_squared((self.x, self.y), (enemy_center[0], enemy_center[1]))
                    
                    if distance <= self.radius**2 + enemy.get_rect().width//2:
                        
                        enemy.hit(self.damage, gl)
    
                        self.hit_list.append(enemy)
    
        else:

            if player in self.hit_list:
                return

            enemy_center = player.get_rect().center
            distance = gl.distance_squared((self.x, self.y), (enemy_center[0], enemy_center[1]))
            
            if distance <= self.radius**2:
                
                player.hit(self.damage, gl, camera)

                self.hit_list.append(player)


    def update(self, gl, player, camera):
        self.radius += self.rps * gl.delta_time
        if self.radius > self.max_radius:
            gl.entities.remove(self)

        self.hit_enemy_check(gl, camera, player)

        if not self.enemy:
            camera.shake(1, 0.1)
        
    def draw(self, screen, camera, gl):
        pos = camera.get_pos(self.x, self.y)
        py.draw.circle(screen, (255, 255, 255), pos, self.radius*gl.scale, 1*gl.scale)

        