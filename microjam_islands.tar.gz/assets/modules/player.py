import pygame as py
from modules.projectile import PROJECTILE

class PLAYER:
    def __init__(self, gl):

        self.dirx = 0
        self.diry = 0
        
        self.x = 8*9.5
        self.y = 8*7.5

        self.w = 5
        self.h = 6

        self.draw_offset = [-2, -3]

        self.xsp = 0
        self.ysp = 0

        self.speed = 55
        self.friction = 10

        self.animation_data = {
            "walking": [
                gl.fragment_spritesheet(gl.load_sprite("assets/walking.png", 1), 8),
                0.13
            ],
        }
        
        self.frames = self.animation_data["walking"][0]
        self.frame_length = self.animation_data["walking"][1]
        self.frame_timer = 0
        self.frame = 0

        self.moving = False
        self.flip_x = False

        self.shoot_vector = [1, 1]
        
        """
        0 - rock, 
        1 - bomb, 
        2 - gun, 
        3 - shuriken, 
        4 - grass blades, 
        """
        
        self.head_items_list = []

        self.item_projectile_data = {
            0: {"speed": 150, "damage": 1.5, "count": 1, "collision": [1, 3, 6, 6]},
            1: {"speed": 70, "damage": 3, "count": 1, "collision": [0, 0, 0, 0]},
            2: {"speed": 130, "damage": 2, "count": 2, "collision": [3, 5, 2, 2]},
            3: {"speed": 85, "damage": 1.25, "count": 1, "collision": [2, 3, 4, 4]},
            4: {"speed": 65, "damage": 2, "count": 2, "collision": [3, 3, 2, 2]},
        }

        self.head_item_count = 0

        self.max_head_item_count = 6

        self.head_item_offset = -5
        self.head_item_frames = gl.fragment_spritesheet(gl.load_sprite("assets/headitems.png", 1), 8)
        self.projectile_frames = gl.fragment_spritesheet(gl.load_sprite("assets/projectiles.png", 1), 8)

        self.bomb_target_frames = gl.fragment_spritesheet(gl.load_sprite("assets/target.png", 1), 7)
        self.crosshair_frames = gl.fragment_spritesheet(gl.load_sprite("assets/crosshair.png", 1), 7)
        
        self.bomb_frame_length = 0.2
        self.bomb_frame_timer = 0
        self.bomb_target_pos = [self.x, self.y]
        self.bomb_frame = 0

        self.rect = py.Rect(self.x, self.y, self.w, self.h)

        self.health = 10
        self.max_health = 10

        self.stun_timer = 0
        self.stun_length = 0.6

    def get_rect(self):
        return self.rect

    def die(self, gl, camera):
        gl.die(camera)

    def reset(self):
        self.health = self.max_health
        self.x = 8*9.5
        self.y = 8*7.5

    def hit(self, damage, gl, camera):
        if self.stun_timer > 0:
            return

        self.health -= damage
        gl.play_sfx("hit")
        camera.shake()
        if self.health <= 0:
            self.die(gl, camera)

        self.stun_timer = self.stun_length

    def add_head_item(self, item_id):
        if len(self.head_items_list) >= self.max_head_item_count:
            return
            
        self.head_items_list.append(item_id)

        if len(self.head_items_list) == 1:
            self.set_head_item_data()

    def set_head_item_data(self):
        self.head_item_count = self.item_projectile_data[self.head_items_list[0]]["count"]

    def shoot_head_item(self, item_id, shoot_vector, gl):
        speed = self.item_projectile_data[item_id]["speed"]
        damage = self.item_projectile_data[item_id]["damage"]
        sprite = self.projectile_frames[item_id]

        pos = [self.x + self.draw_offset[0], self.y + self.draw_offset[1]]

        if item_id != 0 and item_id != 3:
            pos[1] += self.head_item_offset
            
        
        collision = self.item_projectile_data[item_id]["collision"]
        
        gl.entities.append(PROJECTILE(gl, pos[0], pos[1], shoot_vector, speed, damage, sprite, collision, item_id))

    def update(self, gl):
        # input
        self.dirx = (gl.d >= 1) - (gl.a >= 1)
        self.diry = (gl.s >= 1) - (gl.w >= 1)

        if self.dirx != 0 or self.diry != 0:
            self.moving = True
            self.shoot_vector = [self.dirx, self.diry]
        else:
            self.moving = False

        if self.dirx != 0:
            if self.dirx < 0:
                self.flip_x = True
            else:
                self.flip_x = False

        diagonal = (self.dirx != 0) and (self.diry != 0)
        
        # update speed
        target_xsp = self.dirx * self.speed * gl.delta_time * (1 + diagonal * -0.2929)
        target_ysp = self.diry * self.speed * gl.delta_time * (1 + diagonal * -0.2929)
        
        # apply friction
        self.xsp = gl.lerp(self.xsp, target_xsp, self.friction * gl.delta_time)
        self.ysp = gl.lerp(self.ysp, target_ysp, self.friction * gl.delta_time)

        # collisions
        self.x += self.xsp

        if gl.map.collide_rect(self.x, self.y, self.w, self.h):
            while gl.map.collide_rect(self.x, self.y, self.w, self.h):
                self.x -= gl.sign(self.xsp) * 0.1

            self.xsp = 0

        self.y += self.ysp

        if gl.map.collide_rect(self.x, self.y, self.w, self.h):
            while gl.map.collide_rect(self.x, self.y, self.w, self.h):
                self.y -= gl.sign(self.ysp) * 0.1

            self.ysp = 0

        # head item
        if len(self.head_items_list) > 0:
            if gl.space == 1:

                self.shoot_head_item(self.head_items_list[0], self.shoot_vector, gl)
                
                self.head_item_count -= 1
                
                if self.head_item_count == 0:
                    
                    self.head_items_list.pop(0)
                    
                    if len(self.head_items_list) > 0:
                        self.set_head_item_data()
                    else:
                        self.head_item_count = 0

        # update rect
        self.rect.x = self.x
        self.rect.y = self.y

        # stun
        if self.stun_timer >= 0:
            self.stun_timer -= gl.delta_time

    def draw(self, screen, camera, gl):

        # shadow
        gl.draw_shadow(screen, camera, self.x, self.y, self.w, self.h)

        if self.moving:
            self.frame_timer += gl.delta_time
            if self.frame_timer >= self.frame_length:
                self.frame_timer = 0
                self.frame += 1
            if self.frame >= len(self.frames):
                self.frame = 0
        else:
            self.frame = 0

        pos = camera.get_pos(self.x + self.draw_offset[0], self.y + self.draw_offset[1])
        
        sprite = self.frames[self.frame]
        
        if self.flip_x:
            sprite = py.transform.flip(sprite, True, False)

        if self.stun_timer > 0.1:
            sprite = gl.fill_sprite(sprite, (240, 240, 240))
            
        screen.blit(sprite, pos)

        # draw head item
        if len(self.head_items_list) > 0:
            head_item_num = self.head_items_list[0]

            if self.flip_x:
                head_item_sprite = py.transform.flip(self.head_item_frames[head_item_num], True, False)
            else:
                head_item_sprite = self.head_item_frames[head_item_num]

            if self.frame in [1, 2, 4, 5]:
                bump = -1
            else:
                bump = 0
            
            head_item_pos = camera.get_pos(self.x + self.draw_offset[0], self.y + self.draw_offset[1] + self.head_item_offset + bump)
            screen.blit(head_item_sprite, head_item_pos)

            # bomb target pos calc
            range_offset = gl.normalize(self.shoot_vector)
            
            range_offset[0] *= 35
            range_offset[1] *= 35
            
            target_pos =(self.x + self.draw_offset[0] + range_offset[0], self.y + self.draw_offset[1] + range_offset[1])

            self.bomb_target_pos[0] = gl.lerp(self.bomb_target_pos[0], target_pos[0], gl.delta_time * 20)
            self.bomb_target_pos[1] = gl.lerp(self.bomb_target_pos[1], target_pos[1], gl.delta_time * 20)

            # bomb target
            self.bomb_frame_timer += gl.delta_time
            if self.bomb_frame_timer >= self.bomb_frame_length:
                self.bomb_frame_timer = 0
                self.bomb_frame += 1
            if self.bomb_frame >= len(self.bomb_target_frames):
                self.bomb_frame = 0

            if head_item_num == 1:
                bomb_target_sprite = self.bomb_target_frames[self.bomb_frame]
            else:
                bomb_target_sprite = self.crosshair_frames[self.bomb_frame]
                bomb_target_sprite.set_alpha(160)
            
            bomb_target_pos = camera.get_pos(self.bomb_target_pos[0], self.bomb_target_pos[1])
            screen.blit(bomb_target_sprite, bomb_target_pos)

            
 