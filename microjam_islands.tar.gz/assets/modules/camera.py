from random import randint

class CAMERA:
    def __init__(self, screen, gl):
        self.x = 0
        self.y = 0

        self.friction = 10
        
        self.scale = gl.scale

        self.shake_timer = 0

    def update(self, gl):
        self.x = 0
        self.y = 0

        if self.shake_timer > 0:
            self.x += randint(-self.shake_intensity, self.shake_intensity)
            self.y += randint(-self.shake_intensity, self.shake_intensity)
            self.shake_timer -= gl.delta_time

    def get_pos(self, x, y):
        return [round((x - self.x) * self.scale), round((y - self.y) * self.scale)]

    def shake(self, intensity=1, length=0.1):
        self.shake_timer = length
        self.shake_intensity = intensity

        
